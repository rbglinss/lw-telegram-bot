# Bot Telegram LW

Bot Telegram com botões bilíngues (PT/EN) e integração com Pix (PushinPay).
